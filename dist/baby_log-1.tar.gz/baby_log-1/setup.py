from setuptools import setup, find_packages

setup(
    name='baby_log',
    version='1',
    url='http://www.github.com/byt3_m3',
    description='My Baby log App',
    author='Courtney S Baxter Jr',
    author_email='cbaxtertech@gmail.com',
    packages=find_packages(),
    include_package_data=True
)
